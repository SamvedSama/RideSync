package com.carpool.unit;

import com.carpool.service.strategy.FareStrategy;
import com.carpool.service.strategy.StandardFareStrategy;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FareStrategyTest {

    private final FareStrategy strategy = new StandardFareStrategy();

    @Test
    void testCalculateTotalFare_singleSeat() {
        double total = strategy.calculateTotalFare(100.0, 1);
        assertEquals(100.0, total, 0.001);
    }

    @Test
    void testCalculateTotalFare_multipleSeats() {
        double total = strategy.calculateTotalFare(75.0, 3);
        assertEquals(225.0, total, 0.001);
    }

    @Test
    void testCalculateTotalFare_zeroFare() {
        double total = strategy.calculateTotalFare(0.0, 4);
        assertEquals(0.0, total, 0.001);
    }

    @Test
    void testCalculateTotalFare_fractionalFare() {
        double total = strategy.calculateTotalFare(49.99, 2);
        assertEquals(99.98, total, 0.001);
    }

    @Test
    void testCalculateTotalFare_largeValues() {
        double total = strategy.calculateTotalFare(500.0, 8);
        assertEquals(4000.0, total, 0.001);
    }
}
