package com.carpool.integration;

import com.carpool.TestUtils;
import com.carpool.admin.model.AdminAuditLog;
import com.carpool.dto.AuthResponse;
import com.carpool.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.test.annotation.DirtiesContext;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for Admin Management endpoints.
 * All requests authenticate via JWT Bearer token.
 * Non-admin requests must be rejected with 403.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class AdminIntegrationTest {

    @Autowired
    private TestRestTemplate restTemplate;

    private AuthResponse adminAuth;
    private AuthResponse riderAuth;
    private AuthResponse driverAuth;

    @BeforeEach
    void setup() {
        adminAuth  = TestUtils.register(restTemplate, "Admin",  "admin@test.com",  "pass123", "000", UserRole.ADMIN);
        riderAuth  = TestUtils.register(restTemplate, "Rider",  "rider@test.com",  "pass123", "111", UserRole.RIDER);
        driverAuth = TestUtils.register(restTemplate, "Driver", "driver@test.com", "pass123", "222", UserRole.DRIVER);
    }

    // ── Role enforcement ──────────────────────────────────────────────────────

    @Test
    void testAdminEndpoints_unauthenticated_returns401() {
        ResponseEntity<String> resp = restTemplate.getForEntity("/api/admin/users", String.class);
        assertEquals(HttpStatus.UNAUTHORIZED, resp.getStatusCode());
    }

    @Test
    void testAdminEndpoints_nonAdmin_returns403() {
        ResponseEntity<String> resp = restTemplate.exchange(
                "/api/admin/users", HttpMethod.GET,
                TestUtils.authEntity(riderAuth.getToken()), String.class);
        assertEquals(HttpStatus.FORBIDDEN, resp.getStatusCode());
    }

    // ── GET /api/admin/users ──────────────────────────────────────────────────

    @Test
    void testGetAllUsers_admin_succeeds() {
        ResponseEntity<User[]> resp = restTemplate.exchange(
                "/api/admin/users", HttpMethod.GET,
                TestUtils.authEntity(adminAuth.getToken()), User[].class);

        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertTrue(resp.getBody().length >= 3); // admin + rider + driver
    }

    // ── Ban / Unban ───────────────────────────────────────────────────────────

    @Test
    void testBanUser_admin_success() {
        ResponseEntity<User> resp = restTemplate.exchange(
                "/api/admin/users/" + riderAuth.getUserId() + "/ban",
                HttpMethod.PUT,
                TestUtils.authEntity(adminAuth.getToken()), User.class);

        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertTrue(resp.getBody().isBanned(), "User should be banned");
    }

    @Test
    void testBanUser_nonAdmin_returns403() {
        ResponseEntity<String> resp = restTemplate.exchange(
                "/api/admin/users/" + riderAuth.getUserId() + "/ban",
                HttpMethod.PUT,
                TestUtils.authEntity(riderAuth.getToken()), String.class);

        assertEquals(HttpStatus.FORBIDDEN, resp.getStatusCode());
    }

    @Test
    void testBanUser_targetIsAdmin_returns400() {
        // Register a second admin to try banning
        AuthResponse admin2 = TestUtils.register(restTemplate, "Admin2", "admin2@test.com", "pass123", "999", UserRole.ADMIN);

        ResponseEntity<String> resp = restTemplate.exchange(
                "/api/admin/users/" + admin2.getUserId() + "/ban",
                HttpMethod.PUT,
                TestUtils.authEntity(adminAuth.getToken()), String.class);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
    }

    @Test
    void testUnbanUser_success() {
        // Ban first
        restTemplate.exchange("/api/admin/users/" + riderAuth.getUserId() + "/ban",
                HttpMethod.PUT, TestUtils.authEntity(adminAuth.getToken()), User.class);

        // Unban
        ResponseEntity<User> resp = restTemplate.exchange(
                "/api/admin/users/" + riderAuth.getUserId() + "/unban",
                HttpMethod.PUT,
                TestUtils.authEntity(adminAuth.getToken()), User.class);

        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertFalse(resp.getBody().isBanned(), "User should be unbanned");
    }

    @Test
    void testBannedUser_cannotLogin() {
        // Ban the rider
        restTemplate.exchange("/api/admin/users/" + riderAuth.getUserId() + "/ban",
                HttpMethod.PUT, TestUtils.authEntity(adminAuth.getToken()), User.class);

        // Attempt login
        ResponseEntity<String> loginResp = restTemplate.postForEntity(
                "/api/users/login",
                new com.carpool.dto.LoginRequest("rider@test.com", "pass123"),
                String.class);

        assertEquals(HttpStatus.BAD_REQUEST, loginResp.getStatusCode());
        assertTrue(loginResp.getBody().contains("banned"));
    }

    // ── Change role ───────────────────────────────────────────────────────────

    @Test
    void testChangeUserRole_riderToDriver() {
        ResponseEntity<User> resp = restTemplate.exchange(
                "/api/admin/users/" + riderAuth.getUserId() + "/role?role=DRIVER",
                HttpMethod.PUT,
                TestUtils.authEntity(adminAuth.getToken()), User.class);

        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(UserRole.DRIVER, resp.getBody().getRole());
    }

    @Test
    void testChangeUserRole_invalidRole_returns400() {
        ResponseEntity<String> resp = restTemplate.exchange(
                "/api/admin/users/" + riderAuth.getUserId() + "/role?role=SUPERUSER",
                HttpMethod.PUT,
                TestUtils.authEntity(adminAuth.getToken()), String.class);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
    }

    // ── Rides ─────────────────────────────────────────────────────────────────

    @Test
    void testGetAllRides_admin_succeeds() {
        // Create a ride first
        String rideJson = """
                {"source":"A","destination":"B","totalSeats":2,"farePerSeat":50.0,"departureTime":"2030-12-01T09:00:00"}
                """;
        restTemplate.exchange("/api/rides", HttpMethod.POST,
                TestUtils.authEntity(rideJson, driverAuth.getToken()), Ride.class);

        ResponseEntity<Ride[]> resp = restTemplate.exchange(
                "/api/admin/rides", HttpMethod.GET,
                TestUtils.authEntity(adminAuth.getToken()), Ride[].class);

        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertTrue(resp.getBody().length >= 1);
    }

    @Test
    void testAdminCancelRide_success() {
        String rideJson = """
                {"source":"X","destination":"Y","totalSeats":3,"farePerSeat":75.0,"departureTime":"2030-12-01T10:00:00"}
                """;
        ResponseEntity<Ride> rideResp = restTemplate.exchange("/api/rides", HttpMethod.POST,
                TestUtils.authEntity(rideJson, driverAuth.getToken()), Ride.class);
        Long rideId = rideResp.getBody().getId();

        ResponseEntity<Ride> cancelResp = restTemplate.exchange(
                "/api/admin/rides/" + rideId + "/cancel",
                HttpMethod.PUT,
                TestUtils.authEntity(adminAuth.getToken()), Ride.class);

        assertEquals(HttpStatus.OK, cancelResp.getStatusCode());
        assertEquals(RideStatus.CANCELLED, cancelResp.getBody().getStatus());
    }

    @Test
    void testAdminCancelRide_alreadyCancelled_returns400() {
        String rideJson = """
                {"source":"P","destination":"Q","totalSeats":2,"farePerSeat":60.0,"departureTime":"2030-12-01T11:00:00"}
                """;
        ResponseEntity<Ride> rideResp = restTemplate.exchange("/api/rides", HttpMethod.POST,
                TestUtils.authEntity(rideJson, driverAuth.getToken()), Ride.class);
        Long rideId = rideResp.getBody().getId();

        // Cancel once
        restTemplate.exchange("/api/admin/rides/" + rideId + "/cancel",
                HttpMethod.PUT, TestUtils.authEntity(adminAuth.getToken()), Ride.class);

        // Cancel again
        ResponseEntity<String> resp = restTemplate.exchange(
                "/api/admin/rides/" + rideId + "/cancel",
                HttpMethod.PUT, TestUtils.authEntity(adminAuth.getToken()), String.class);

        assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode());
    }

    // ── Audit log ─────────────────────────────────────────────────────────────

    @Test
    void testAuditLog_recordedAfterBan() {
        restTemplate.exchange("/api/admin/users/" + riderAuth.getUserId() + "/ban",
                HttpMethod.PUT, TestUtils.authEntity(adminAuth.getToken()), User.class);

        ResponseEntity<AdminAuditLog[]> auditResp = restTemplate.exchange(
                "/api/admin/audit", HttpMethod.GET,
                TestUtils.authEntity(adminAuth.getToken()), AdminAuditLog[].class);

        assertEquals(HttpStatus.OK, auditResp.getStatusCode());
        assertTrue(auditResp.getBody().length >= 1);

        AdminAuditLog entry = auditResp.getBody()[0];
        assertEquals("USER", entry.getTargetType());
        assertEquals(adminAuth.getUserId(), entry.getAdminId());
    }

    @Test
    void testAuditLog_filterByAdmin() {
        restTemplate.exchange("/api/admin/users/" + riderAuth.getUserId() + "/ban",
                HttpMethod.PUT, TestUtils.authEntity(adminAuth.getToken()), User.class);

        ResponseEntity<AdminAuditLog[]> auditResp = restTemplate.exchange(
                "/api/admin/audit/by-admin", HttpMethod.GET,
                TestUtils.authEntity(adminAuth.getToken()), AdminAuditLog[].class);

        assertEquals(HttpStatus.OK, auditResp.getStatusCode());
        assertTrue(auditResp.getBody().length >= 1);
        for (AdminAuditLog log : auditResp.getBody()) {
            assertEquals(adminAuth.getUserId(), log.getAdminId());
        }
    }
}
